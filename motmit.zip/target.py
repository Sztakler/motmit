class Target:
    def __init__(self, index, mirror_index, circle_index):
        self.orbit_index = index
        self.mirror_orbit_index = mirror_index
        self.circle_index = circle_index
